<?php
define('LBL_MANDATORY','*');
//Home
define('LBL_TITLE','Language Link China');
define('LBL_ABOUT_US','About us');
define('LBL_PRESS_RELEASE','Press release');
define('LBL_ACCREDITATION','Accreditation');
define('LBL_LLI','Language Link China');
define('LBL_OUR_TEACHERS','Our teachers');
define('LBL_OUR_STUDENTS','Our Students');
define('LBL_TV','TV');

define('LBL_ENGLISH','English');
define('LBL_CHINESE','Chinese');

define('LBL_MAIN_HEAD_HOME','Home');
define('LBL_MAIN_HEAD_ENGLISH_ONLINE','English Online');
define('LBL_MAIN_HEAD_DOWNLOAD','Download our Brochure!');
define('LBL_MAIN_HEAD_CONTACTUS','Contact Us');
define('LBL_MAIN_HEAD_FRANCHISING','Franchising');

define('HOME_IMAGE_OVER',"London, England Language Union College was founded in 1975, the creation of over 100 offices and schools, English language training in over 20 countries in the world.London English in 2008 was certified as a formal Sino-foreign joint schools School, University of Cambridge and Trinity College London and has authorized an international English language training courses and examinations, including the Trinity College of Cambridge Young Learners English, IELTS, TOEFL and London English examination. London English is the Beijing region's only authorized access to the University of Cambridge Teacher Training Centre is also China's only of the teacher qualification training institutions on a regular basis.Our slogan is the pursuit of excellence in the quality of teaching, our goal is to provide high-quality English language training, we have an experienced team of native English speaking teachers, we focus on improving students English fluency.");

define('HOME_IMAGE_VIEW_NORE',"View more");
define('HOME_IMAGE_GET_ACCOUNT',"Get an Account");
define('HOME_IMAGE_CALL','Call');






